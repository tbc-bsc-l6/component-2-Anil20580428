<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FooterShortDesc extends Model
{
    protected $table = 'footer_short_descs';
    protected $fillable = ['description'];
}
