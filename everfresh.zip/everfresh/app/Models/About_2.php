<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class About_2 extends Model
{
    protected $table = 'abouts_2';
    protected $fillable = ['heading', 'description'];
}
