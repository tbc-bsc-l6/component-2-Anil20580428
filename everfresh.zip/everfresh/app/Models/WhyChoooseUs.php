<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WhyChoooseUs extends Model
{
    protected $table = 'why_chooose_us';
    protected $fillable = ['description'];
}
