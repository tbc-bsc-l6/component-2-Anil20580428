<?php

namespace App\Http\Controllers;

use App\Models\AwesomeServiceTitle;
use App\Models\Hometop;
use App\Models\OurBannerFooter;
use Illuminate\Http\Request;

class AwesomeServiceController extends Controller
{
    public function index()
    {
        // $awesomeServiceTitle = AwesomeServiceTitle::first();
        // $homeTop = Hometop::first();
        // $footerBanner = OurBannerFooter::first();

        // return view('service',compact('awesomeServiceTitle','homeTop','footerBanner'));
    }
}
