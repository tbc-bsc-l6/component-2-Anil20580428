<?php echo $__env->make('template.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('template.navlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="breadcrumbSection">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="pageTitle">
                        <h2>Gallery</h2>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="pageBreadcrumb">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <span>&nbsp; / &nbsp;</span>
                        <a href="#">Blog</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="commonSection noPaddingBottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sectionTitle text-center">
                        <h2> <?php echo e($homeOurProject->title); ?></h2>
                        <div class="titleBar"></div>
                        <p>
                           <?php echo e($homeOurProject->description); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container my-3">
            <div class="row">
                
           
            <?php $__currentLoopData = $homeOurProjectList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        
            <div class="col-lg-3 col-md-6">
                <div class="card" style="width: 100%;">
                <img src="<?php echo e(asset('storage/'.$item->image)); ?>" class="card-img-top" alt="...">
                
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

   
    </section>

   <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/gallery.blade.php ENDPATH**/ ?>