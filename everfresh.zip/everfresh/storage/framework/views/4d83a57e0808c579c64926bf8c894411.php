

<?php $__env->startSection('content'); ?>
    <div class="mt-4">
      
        <table class="table table-hover table-center">
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th class="text-center">Address</th>
                    <th class="text-right">Service Type</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $serviceBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-nowrap">
                        <div><?php echo e($book->id); ?></div>
                    </td>
                    <td class="text-nowrap"><?php echo e($book->name); ?></td>
                    <td><?php echo e($book->phone); ?></td>
                    <td class="text-center"><?php echo e($book->address); ?></td>
                    <td class="text-right"><?php echo e($book->choose); ?></td>
                    <td class="text-center">
                        <div class="d-flex justify-content-center gap-2">
                            <!-- Status Toggle Form -->
                            <form action="<?php echo e(route('service.toggle.status', $book->id)); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit" class="btn btn-sm btn-<?php echo e($book->status ? 'success' : 'danger'); ?> d-flex align-items-center">
                                    <i class="bi bi-<?php echo e($book->status ? 'check-circle' : 'x-circle'); ?> me-1"></i>
                                    <?php echo e($book->status ? 'Active' : 'Inactive'); ?>

                                </button>
                            </form>
            
                            <!-- View Button (for modal) -->
                            <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#viewBookingModal<?php echo e($book->id); ?>">
                                View
                            </button>
            
                            <!-- Delete Form -->
                            <form action="<?php echo e(route('service.delete', $book->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this booking?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="bi bi-trash me-1"></i> Delete
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
        </table>
        
        <!-- Modal Template for Booking Details -->
        <?php $__currentLoopData = $serviceBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="viewBookingModal<?php echo e($book->id); ?>" tabindex="-1" role="dialog" aria-labelledby="viewBookingModalLabel<?php echo e($book->id); ?>" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="viewBookingModalLabel<?php echo e($book->id); ?>">Booking Details - <?php echo e($book->name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Booking ID:</strong> <?php echo e($book->id); ?></p>
                        <p><strong>Name:</strong> <?php echo e($book->name); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($book->phone); ?></p>
                        <p><strong>Address:</strong> <?php echo e($book->address); ?></p>
                        <p><strong>Post Code:</strong> <?php echo e($book->postcode); ?></p>
                        <p><strong>City:</strong> <?php echo e($book->city); ?></p>
                        <p><strong>Service Type:</strong> <?php echo e($book->choose); ?></p>
                        <p><strong>Status:</strong> <?php echo e($book->status ? 'Active' : 'Inactive'); ?></p>
                        <p><strong>Comment:</strong> <?php echo e($book->comment); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        <!-- Modal Template -->
        <?php $__currentLoopData = $serviceBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="viewBookingModal<?php echo e($book->id); ?>" tabindex="-1" role="dialog" aria-labelledby="viewBookingModalLabel<?php echo e($book->id); ?>" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="viewBookingModalLabel<?php echo e($book->id); ?>">Booking Details - <?php echo e($book->name); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Booking ID:</strong> <?php echo e($book->id); ?></p>
                        <p><strong>Name:</strong> <?php echo e($book->name); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($book->phone); ?></p>
                        <p><strong>Address:</strong> <?php echo e($book->address); ?></p>
                        <p><strong>Service Type:</strong> <?php echo e($book->choose); ?></p>
                        <p><strong>Status:</strong> <?php echo e($book->status ? 'Active' : 'Inactive'); ?></p>
                        <p><strong>Comment:</strong> <?php echo e($book->comment); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/servicebook.blade.php ENDPATH**/ ?>