

<?php $__env->startSection('content'); ?>
<div class="row mt-3 d-flex justify-content-center align-items-center">
    <div class="col-lg-8 text-center">
        <div class="card" style="width: 100%;">
            <div class="card-body">
              <form action="<?php echo e(route('meetout.team.update')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>                
                <div class="form-group mt-1">
                    <input name="heading" type="text" class="form-control" id="heading" name="heading" value="<?php echo e($meetourteam->heading); ?>">
                </div>
                
                <div class="form-group mt-2">
                    <textarea name="description" class="form-control" id="paragraph" name="paragraph" rows="4"><?php echo e($meetourteam->description); ?></textarea>
                </div>
                                
                <button type="submit" class="btn btn-info mt-1">Update</button>
              </form>
            </div>
          </div>
    </div>
</div>
<div class="row mt-3">
    <!-- Table Section -->
    <div class="col-lg-8 col-md-12">
        <div class="card">
            <div class="card-header bg-info text-white text-center">
                <h4>Team Members</h4>
            </div>
            <div class="card-body">
                <table class="table table-bordered text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>Sr</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td>
                                <?php if($member->image): ?>
                                    <img src="<?php echo e(asset($member->image)); ?>" alt="<?php echo e($member->name); ?>" width="50" height="50" class="img-thumbnail">
                                <?php else: ?>
                                    <span>No Image</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($member->name); ?></td>
                            <td><?php echo e($member->position); ?></td>
                            <td>
                                <!-- Toggle Status -->
                                <form action="<?php echo e(route('member.toggleStatus', $member->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <?php if($member->status == 1): ?>
                                        <button type="submit" class="btn btn-success btn-sm">Active</button>
                                    <?php else: ?>
                                        <button type="submit" class="btn btn-info btn-sm">Inactive</button>
                                    <?php endif; ?>
                                </form>
                
                                <!-- Edit Button -->
                                <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#memberEdit<?php echo e($member->id); ?>">Edit</button>
                
                                <!-- Delete Button -->
                                <form action="<?php echo e(route('member.destroy', $member->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this member?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                
                        <!-- Modal for Editing Member -->
                        <div class="modal fade" id="memberEdit<?php echo e($member->id); ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editModalLabel">Edit Member</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <form action="<?php echo e(route('member.update', $member->id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="name">Name</label>
                                                <input type="text" name="name" class="form-control" value="<?php echo e($member->name); ?>" required>
                                            </div>
                                            <div class="form-group mt-2">
                                                <label for="position">Position</label>
                                                <input type="text" name="position" class="form-control" value="<?php echo e($member->position); ?>" required>
                                            </div>
                                            <div class="form-group mt-2">
                                                <label for="image">Image</label>
                                                <input type="file" name="image" class="form-control">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No Members Found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>

    <!-- Form Section -->
    <div class="col-lg-4 col-md-12">
        <div class="card">
            <div class="card-header bg-info text-white text-center">
                <h4>Add Member</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('member.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mt-1">
                        <label for="name">Name</label>
                        <input name="name" type="text" class="form-control" id="name" placeholder="Member Name" required>
                    </div>
                    <div class="form-group mt-1">
                        <label for="position">Position</label>
                        <input name="position" type="text" class="form-control" id="position" placeholder="Member Position" required>
                    </div>
                    <div class="form-group mt-2">
                        <label for="image">Image</label>
                        <input type="file" class="form-control" id="image" name="image">
                    </div>
                    <button type="submit" class="btn btn-info mt-3 w-100">Add Member</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/meetourteams.blade.php ENDPATH**/ ?>