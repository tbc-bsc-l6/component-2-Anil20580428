<?php echo $__env->make('template.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('template.navlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="breadcrumbSection">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="pageTitle">
                    <h2>About us</h2>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="pageBreadcrumb">
                    <a href="<?php echo e(url('/')); ?>">Home</a>
                    <span>&nbsp; / &nbsp;</span>
                    <a href="#">Shop</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="commonSection bggray noPaddingBottom welcomeSec">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-6 text-center center">
                <div class="spSecTitle">
                    <h2>
                        <?php echo e($about2->heading); ?>

                    </h2>
                    <div class="titleBar"></div>
                    <p>
                        <?php echo e($about2->description); ?>

                    </p>
                </div>
            </div>
        </div>
        
    </div>
    <div class="welclean">
        <div class="welimg wow fadeInUp" data-wow-duration="700ms" data-wow-delay="300ms">
            <img src="https://themewar.com/html/myclean/images/home1/welcome.jpg" alt>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 iconbox1wrap">
                    <div class="row">
                       
                        <?php $__currentLoopData = $homeAboutLeft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                       <div class="col-sm-6 text-right wow fadeInUp" data-wow-duration="700ms"
                        data-wow-delay="450ms">
                       <div class="iconbox1">
                           <i class="fa-brands fa-react"></i>
                           <h2><?php echo e($item->title); ?></h2>
                           <p>
                               <?php echo e($item->description); ?>

                           </p>
                       </div>
                        </div>
                
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

   
    
<section class="commonSection noPaddingBottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="sectionTitle text-center">
                    <h2> <?php echo e($meetOurteam->heading); ?></h2>
                    <div class="titleBar"></div>
                    <p>
                        <?php echo e($meetOurteam->description); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 teamWrap">
                <?php $__currentLoopData = $teamMember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="singleTeam">
                    <div class="singtemimg">
                        <img src="<?php echo e(asset($team->image)); ?>" alt>
                    </div>
                    <div class="sintemDec">
                        <h3><?php echo e($team->name); ?></h3>
                        <h4><?php echo e($team->position); ?></h4>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
</section>

<section class="overlay70B funfactbg">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-duration="700ms" data-wow-delay="300ms">
                <div class="singleFun">
                    <!-- <i class="clean-Clean-Counter-1"></i> -->
                    <i class="fa-regular fa-star"></i>
                    <h2 class="fmOpensans count" data-counter="25">25</h2>
                    <p>Shine Experience</p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-duration="700ms" data-wow-delay="350ms">
                <div class="singleFun">
                    <!-- <i class="clean-Clean-Counter-2"></i> -->
                    <i class="fa-regular fa-star"></i>
                    <h2 class="fmOpensans count" data-counter="900">900 <span>+</span></h2>
                    <p>Shine Experience</p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-duration="700ms" data-wow-delay="400ms">
                <div class="singleFun">
                    <!-- <i class="clean-Clean-Counter-3"></i> -->
                    <i class="fa-regular fa-star"></i>
                    <h2 class="fmOpensans count" data-counter="150">150</h2>
                    <p>Shine Experience</p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-duration="700ms" data-wow-delay="450ms">
                <div class="singleFun">
                    <!-- <i class="clean-Clean-Counter-4"></i> -->
                    <i class="fa-regular fa-star"></i>
                    <h2 class="fmOpensans count" data-counter="30">30</h2>
                    <p>Shine Experience</p>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="faq2Sec">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6">
                <div class="paq2wrap">
                    <div class="sectionTitle">
                        <h2>FAQ</h2>
                        <div class="titleBar left"></div>
                        <p>
                            <?php echo e($faq->description); ?>

                        </p>
                    </div>
                    <div class="faqaccordion2">
                        <div class="panel-group" id="accordion">
                            <?php $__currentLoopData = $faqAddList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="panel">
                                <div class="panelHeading2">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#faq<?php echo e($item->id); ?>"
                                        class="panel-title">
                                        <?php echo e($item->heading); ?>

                                    </a>
                                </div>
                                <div id="faq<?php echo e($item->id); ?>" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>
                                            <?php echo e($item->description); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 bggraybok">
                <div class="servicesBooking">
                    <div class="sectionTitle">
                        <h2>Service Booking</h2>
                        <div class="titleBar left"></div>
                        <p>
                            The helpless the powerless in a world of criminals who operate above the law texas
                            tea here is the story of a man named Brady
                        </p>
                    </div>
                    <div class="row">
                        <div class="servicesContact2">
                            <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form action="<?php echo e(route('user.service.book')); ?>" method="post" id="servicesForm">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-lg-6">
            <input type="text" name="ser_name" class="required" id="ser_name" value="<?php echo e(old('ser_name')); ?>" placeholder="Name *">
            <?php $__errorArgs = ['ser_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-lg-6">
            <input type="email" name="ser_email" class="required" id="ser_email" value="<?php echo e(old('ser_email')); ?>" placeholder="Email *">
            <?php $__errorArgs = ['ser_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-lg-6">
            <input type="text" name="ser_phone" class="required" id="ser_phone" value="<?php echo e(old('ser_phone')); ?>" placeholder="Phone Number *">
            <?php $__errorArgs = ['ser_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-lg-6">
            <input type="text" name="ser_post" class="required" id="ser_post" value="<?php echo e(old('ser_post')); ?>" placeholder="Zip / Postal Code *">
            <?php $__errorArgs = ['ser_post'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-lg-12">
            <input type="text" name="ser_adds" class="required" id="ser_adds" value="<?php echo e(old('ser_adds')); ?>" placeholder="Address *">
            <?php $__errorArgs = ['ser_adds'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-lg-6">
            <input type="text" name="ser_city" class="required" id="ser_city" value="<?php echo e(old('ser_city')); ?>" placeholder="City *">
            <?php $__errorArgs = ['ser_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-lg-6">
            <select name="ser_option" id="ser_option" class="required">
                <option value selected>Choose a Service</option>
                <option value="saab" <?php echo e(old('ser_option') == 'saab' ? 'selected' : ''); ?>>Saab</option>
                <option value="mercedes" <?php echo e(old('ser_option') == 'mercedes' ? 'selected' : ''); ?>>Mercedes</option>
                <option value="audi" <?php echo e(old('ser_option') == 'audi' ? 'selected' : ''); ?>>Audi</option>
            </select>
            <?php $__errorArgs = ['ser_option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-lg-12">
            <textarea name="ser_comment" class="required" id="ser_comment" placeholder="Comments"><?php echo e(old('ser_comment')); ?></textarea>
            <?php $__errorArgs = ['ser_comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-lg-12">
            <button type="submit" id="ser_submit">Submit</button>
        </div>
    </div>
</form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php /**PATH D:\WebLink\everfresh\resources\views/about.blade.php ENDPATH**/ ?>