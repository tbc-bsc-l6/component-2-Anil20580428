

<?php $__env->startSection('content'); ?>
<div class="container mt-4">


    <div class="card">
        <div class="card-header">
            <h3>Social Media Links</h3>
        </div>
        <div class="card-body">
            <!-- Add Social Media Form -->
            <form action="<?php echo e(route('social.media.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="platform">Platform</label>
                    <input type="text" name="platform" id="platform" class="form-control" placeholder="Enter social media platform" value="<?php echo e(old('platform')); ?>">
                    <?php $__errorArgs = ['platform'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="link">Link</label>
                    <input type="url" name="link" id="link" class="form-control" placeholder="Enter social media link" value="<?php echo e(old('link')); ?>">
                    <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary mt-2">Add Social Media</button>
            </form>

            <!-- Social Media Links Table -->
            <table class="table table-hover mt-4">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Platform</th>
                        <th>Link</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $socialMediaLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($link->platform); ?></td>
                        <td><a href="<?php echo e($link->link); ?>" target="_blank"><?php echo e($link->link); ?></a></td>
                        <td>
                            <!-- Edit Button -->
                            <button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#editModal<?php echo e($link->id); ?>">Edit</button>

                            <!-- Delete Form -->
                            
                        </td>
                    </tr>

                    <!-- Edit Modal -->
                    <div class="modal fade" id="editModal<?php echo e($link->id); ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="<?php echo e(route('social.media.update', $link->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editModalLabel">Edit Social Media</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="platform">Platform</label>
                                            <input type="text" name="platform" id="platform" class="form-control" value="<?php echo e($link->platform); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="link">Link</label>
                                            <input type="url" name="link" id="link" class="form-control" value="<?php echo e($link->link); ?>">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/socialMedia.blade.php ENDPATH**/ ?>