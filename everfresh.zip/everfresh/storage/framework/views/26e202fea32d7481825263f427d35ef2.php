
<section class="sliderSection">
    <div class="container-fluid">
        <div class="row">
            <div class="tp-banner">
                <ul>
                    <?php $__currentLoopData = $homeSlider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
                    <li data-transition="cube" data-slotamount="7" data-masterspeed="1000">
                        <img src="<?php echo e(asset($slider->sliderimage)); ?>" alt>
                        <div class="tp-caption sfb" data-x="left" data-y="center" data-hoffset="-85"
                            data-voffset="-90" data-speed="1600" data-start="1500" data-easing="Power4.easeOut">
                            <div class="revCont">
                                <h1><?php echo e($slider->heading1); ?></h1>
                                <h2><?php echo e($slider->heading2); ?></h2>
                            </div>
                        </div>
                        <div class="tp-caption sfb" data-x="left" data-y="center" data-hoffset="-83"
                            data-voffset="30" data-speed="2000" data-start="2500" data-easing="Power4.easeOut">
                            <div class="revCont">
                                <p>
                                    <?php echo e($slider->description); ?>

                                </p>
                            </div>
                        </div>
                        <div class="tp-caption sfb text-left" data-x="left" data-y="center" data-hoffset="-83"
                            data-voffset="112" data-speed="2000" data-start="3000" data-easing="Power4.easeOut">
                            <div class="revBtn">
                                <a class="cleanBtn_style2" href="#">Get free Estimate <i
                                        class="fa fa-angle-right"></i></a>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</section>


<section class="findlocation bggray">
    <div class="container">
        <div class="row">
            <div class="findlocationbg overlay85">
                <div class="col-sm-5 text-center">
                    <div class="leftinfo">
                        <h1><?php echo e($sliderLeft->heading); ?></h1>
                        <div class="addsloc">
                            <p><?php echo e($sliderLeft->day1); ?></p>
                            <p><?php echo e($sliderLeft->day2); ?></p>
                        </div>
                        <h2><?php echo e($sliderLeft->title); ?></h2>
                        <h3>+977 <?php echo e($sliderLeft->phone); ?></h3>
                    </div>
                </div>
                <div class="col-sm-7 text-center">
                    <div class="findform">
                        <h2><?php echo e($sliderRight->heading); ?></h2>
                        <p>
                            <?php echo e($sliderRight->description); ?>

                        </p>
                        <form action="#">
                            <input type="text" placeholder="Enter Your Postal Code / Zip">
                            <button type="submit">Find Location</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\WebLink\everfresh\resources\views/template/home_slider.blade.php ENDPATH**/ ?>