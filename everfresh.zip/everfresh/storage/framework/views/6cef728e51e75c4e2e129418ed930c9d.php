<?php echo $__env->make('template.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('template.navlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('template.home_slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <section class="commonSection bggray noPaddingBottom welcomeSec">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-6 text-center center">
                    <div class="spSecTitle">
                        <h2>
                            <?php echo e($homeAbout->heading); ?>

                        </h2>
                        <div class="titleBar"></div>
                        <p>
                            <?php echo e($homeAbout->description); ?>

                        </p>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="welclean">
            <div class="welimg wow fadeInUp" data-wow-duration="700ms" data-wow-delay="300ms">
                <img src="https://themewar.com/html/myclean/images/home1/welcome.jpg" alt>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 iconbox1wrap">
                        <div class="row">
                           
                            <?php $__currentLoopData = $homeAboutLeft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                           <div class="col-sm-6 text-right wow fadeInUp" data-wow-duration="700ms"
                            data-wow-delay="450ms">
                           <div class="iconbox1">
                               <i class="fa-brands fa-react"></i>
                               <h2><?php echo e($item->title); ?></h2>
                               <p>
                                   <?php echo e($item->description); ?>

                               </p>
                           </div>
                            </div>
                    
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="commonSection noPaddingBottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sectionTitle text-center">
                        <h2> <?php echo e($homeOurProject->title); ?></h2>
                        <div class="titleBar"></div>
                        <p>
                           <?php echo e($homeOurProject->description); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="text-center">
                    <div class="filterNav">
                        <ul class="nav nav-tabs filterNav" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">All Projects</a>
                            </li>
                            <li role="presentation">
                                <a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Flooring</a>
                            </li>
                            <li role="presentation">
                                <a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Commercial</a>
                            </li>
                            <li role="presentation">
                                <a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab">Exterior</a>
                            </li>
                            <li role="presentation">
                                <a href="#tab5" aria-controls="tab5" role="tab" data-toggle="tab">Streaming</a>
                            </li>
                            <li role="presentation">
                                <a href="#tab6" aria-controls="tab6" role="tab" data-toggle="tab">Others</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="tab1">
                        <?php $__currentLoopData = $homeOurProjectList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        
                        <div class="portfolio-item">
                            <img src="<?php echo e(asset('storage/'.$all->image)); ?>"
                                class="img-responsive" alt="Portfolio Image 1">
                                
                            <div class="custom-overlay">
                                <div class="overlay-content">
                                    <a href="https://themewar.com/html/myclean/images/portfolio/4c/1.jpg" class="swipebox"><i
                                            class="icon-Search"></i></a>
                                    <h3><a href="<?php echo e(url('project/details',$all->id)); ?>"><?php echo e($all->title); ?></a></h3>
                                    <p><?php echo e($all->projectType); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div role="tabpanel" class="tab-pane" id="tab2">
                        
                        <?php $__currentLoopData = $ourFlooring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flooring): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($flooring->projectType == 'flooring'): ?>
                            
                            <div class="portfolio-item">
                                <img src="<?php echo e(asset('storage/'.$flooring->image)); ?>" class="img-responsive" alt="Portfolio Image">
                                <div class="custom-overlay">
                                    <div class="overlay-content">
                                        <a href="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg" class="swipebox"><i class="icon-Search"></i></a>
                                        <h3><a href="<?php echo e(url('project/deatils/',$flooring->id)); ?>"><?php echo e($flooring->title); ?></a></h3>
                                        <p><?php echo e($flooring->projectType); ?></p>
                                    </div>
                                </div>
                            </div> 
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                        
                    </div>
                    

                    <div role="tabpanel" class="tab-pane" id="tab3">
                        <?php $__currentLoopData = $ourCommerical; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commerical): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($commerical->projectType == 'commercial'): ?>
                            
                            <div class="portfolio-item">
                                <img src="<?php echo e(asset('storage/'.$commerical->image)); ?>" class="img-responsive" alt="Portfolio Image">
                                <div class="custom-overlay">
                                    <div class="overlay-content">
                                        <a href="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg" class="swipebox"><i class="icon-Search"></i></a>
                                        <h3><a href="<?php echo e(url('project/details',$commerical->id)); ?>"><?php echo e($commerical->title); ?></a></h3>
                                        <p><?php echo e($commerical->projectType); ?></p>
                                    </div>
                                </div>
                            </div> 
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                        
                    </div>

                    <div role="tabpanel" class="tab-pane" id="tab4">
                        <?php $__currentLoopData = $ourExterior; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exterior): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($exterior->projectType == 'exterior'): ?>
                            
                            <div class="portfolio-item">
                                <img src="<?php echo e(asset('storage/'.$exterior->image)); ?>" class="img-responsive" alt="Portfolio Image">
                                <div class="custom-overlay">
                                    <div class="overlay-content">
                                        <a href="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg" class="swipebox"><i class="icon-Search"></i></a>
                                        <h3><a href="<?php echo e(url('project/details',$exterior->id)); ?>"><?php echo e($exterior->title); ?></a></h3>
                                        <p><?php echo e($exterior->projectType); ?></p>
                                    </div>
                                </div>
                            </div> 
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>

                    <div role="tabpanel" class="tab-pane" id="tab5">
                        <?php $__currentLoopData = $ourStreaming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $streaming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($streaming->projectType == 'streaming'): ?>
                            
                            <div class="portfolio-item">
                                <img src="<?php echo e(asset('storage/'.$streaming->image)); ?>" class="img-responsive" alt="Portfolio Image">
                                <div class="custom-overlay">
                                    <div class="overlay-content">
                                        <a href="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg" class="swipebox"><i class="icon-Search"></i></a>
                                        <h3><a href="<?php echo e(url('project/details',$streaming->id)); ?>"><?php echo e($streaming->title); ?></a></h3>
                                        <p><?php echo e($streaming->projectType); ?></p>
                                    </div>
                                </div>
                            </div> 
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div role="tabpanel" class="tab-pane" id="tab6">
                        <?php $__currentLoopData = $ourOther; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($other->projectType == 'other'): ?>
                            
                            <div class="portfolio-item">
                                <img src="<?php echo e(asset('storage/'.$other->image)); ?>" class="img-responsive" alt="Portfolio Image">
                                <div class="custom-overlay">
                                    <div class="overlay-content">
                                        <i class="icon-Search"></i>
                                        <h3><a href="<?php echo e(url('project/details',$other->id)); ?>"><?php echo e($other->title); ?></a></h3>
                                        <p><?php echo e($other->projectType); ?></p>
                                    </div>
                                </div>
                            </div> 
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="calltoaction">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-12">
                    <div class="logo2call">
                        <img src="<?php echo e(asset('storage/'.$banner->logo)); ?>" alt>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-12 noPaddingLeft">
                    <div class="calltoCont">
                        <h2><?php echo e($banner->heading); ?></h2>
                        <p>
                            <?php echo e($banner->description); ?>

                        </p>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-12 text-right">
                    <div class="calltobtn">
                        <a href="#" class="cleanBtn_style2">Get free Estimate <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="commonSection servicessec">
        <div class="container-fluid">
            <div class="row servPadding">
                <div class="col-lg-7">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="sectionTitle awesomeSer">
                                <h2>
                                    <?php echo e($awesomeServiceTitle->heading); ?>

                                </h2>
                                <div class="titleBar left"></div>
                                <p>
                                    <?php echo e($awesomeServiceTitle->description); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $awesomeService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <div class="col-sm-6 noPaddingRight wow fadeInUp" data-wow-duration="700ms"
                            data-wow-delay="300ms">
                            <div class="iconbox2">
                                <i class="fa-solid fa-broom"></i>
                                <h2><?php echo e($service->title); ?></h2>
                                <p>
                                    <?php echo e($service->description); ?>

                                </p>
                            </div>
                        </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
                    </div>
                </div>
                <div class="col-lg-5 col-sm-12 noPadding">
                    <div class="servicesContact">
                        <form action="#" method="post" id="servicesForm">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h2 class="serconttitle">Service Booking</h2>
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" placeholder="Name *" id="ser_name" name="ser_name"
                                        class="required">
                                </div>
                                <div class="col-lg-6">
                                    <input type="email" placeholder="Email *" id="ser_email" name="ser_email"
                                        class="required">
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" placeholder="Phone Number *" id="ser_phone" name="ser_phone"
                                        class="required">
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" placeholder="Zip / Postal Code *" id="ser_post" name="ser_post"
                                        class="required">
                                </div>
                                <div class="col-lg-12">
                                    <input type="text" placeholder="Address *" id="ser_adds" name="ser_adds"
                                        class="required">
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" placeholder="City *" id="ser_city" name="ser_city"
                                        class="required">
                                </div>
                                <div class="col-lg-6">
                                    <select id="ser_option" class="required" name="ser_option">
                                        <option selected value>choose a services</option>
                                        <option value="Clean">Clean</option>
                                        <option value="mercedes">Mercedes</option>
                                        <option value="audi">Audi</option>
                                    </select>
                                </div>
                                <div class="col-lg-12">
                                    <textarea placeholder="Comments" id="ser_comment" name="ser_comment"
                                        class="required"></textarea>
                                </div>
                                <div class="col-lg-12">
                                    <button type="submit" id="ser_submit">submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="testmonuial overlay80">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center" id="testcarohome1">
                    <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="singleTest">
                        <div class="testimg">
                            <img src="<?php echo e(asset('storage/'.$r->logo)); ?>" alt>
                        </div>
                        <div class="testCont">
                            <p>
                                <?php echo e($r->description); ?>

                            </p>
                        </div>
                        <div class="testdeg">
                            <h4><?php echo e($r->name); ?></h4>
                            <p><?php echo e($r->position); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </section>


    <section class="commonSection noPaddingBottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sectionTitle text-center">
                        <h2> <?php echo e($meetOurteam->heading); ?></h2>
                        <div class="titleBar"></div>
                        <p>
                            <?php echo e($meetOurteam->description); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 teamWrap">
                    <?php $__currentLoopData = $teamMember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="singleTeam">
                        <div class="singtemimg">
                            <img src="<?php echo e(asset($team->image)); ?>" alt>
                        </div>
                        <div class="sintemDec">
                            <h3><?php echo e($team->name); ?></h3>
                            <h4><?php echo e($team->position); ?></h4>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </section>


    <section class="commonSection bggray plansec">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sectionTitle text-center">
                        <h2> <?php echo e($ourBestPlan->heading); ?></h2>
                        <div class="titleBar"></div>
                        <p>
                            <?php echo e($ourBestPlan->description); ?>

                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $ourBestPlanToure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6 text-center wow fadeInUp" data-wow-duration="700ms"
                data-wow-delay="300ms">
                <div class="singlePlan">
                    <div class="planHead">
                        <span class="dollcar">$</span>
                        <p class="price"><?php echo e($item->price); ?></p>
                        <span class="monthPlan">/ mon</span>
                    </div>
                    <div class="planTitle">
                        <p><?php echo e($item->planType); ?></p>
                    </div>
                    <div class="planbody">
                        <ul>
                            <li><?php echo e($item->feature); ?></li>
                            <li><?php echo e($item->cleaning); ?></li>
                            <li><?php echo e($item->moving); ?></li>
                            <li><?php echo e($item->calling); ?></li>
                            <li><?php echo e($item->work); ?></li>
                            <li><?php echo e($item->suggestion); ?></li>
                            <li><?php echo e($item->security); ?></li>
                        </ul>
                    </div>
                    <div class="planFoot">
                        <a href="#" class="cleanBtn_style2">Buy Now <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
               
            </div>
        </div>
    </section>


    <section class="videoSection overlay70v">
        <div id="videoWrap1">
            <video id="myVideo1" muted loop poster="images/welcome.jpg">
                <source src="https://themewar.com/html/myclean/video/video.mp4" type="video/mp4">
            </video>
        </div>
        <div class="vidContent">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h2>Welcome to</h2>
                        <div class="playBtn">
                            <a href="javascript:void('0')" id="playVideos"></a>
                        </div>
                        <h3> EVERFRESH</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="commonSection faqsec">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 noPaddingRight">
                    <div class="paqwrap">
                        <div class="sectionTitle marginBbottom40">
                            <h2>FAQ</h2>
                            <div class="titleBar left"></div>
                            <p>
                                <?php echo e($faq->description); ?>

                            </p>
                        </div>
                        <div class="faqaccordion">
                            <div class="panel-group" id="accordion">
                                <?php $__currentLoopData = $faqAddList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel">
                                    <div class="panelHeading">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#faq<?php echo e($item->id); ?>"
                                            class="panel-title">
                                            <i class="fa-solid fa-plus"></i>
                                            <?php echo e($item->heading); ?>

                                        </a>
                                    </div>
                                    <div id="faq<?php echo e($item->id); ?>" class="panel-collapse collapse">
                                        <div class="panel-body">
                                            <p>
                                               <?php echo e($item->description); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 noPaddingLeft">
                    <div class="brustedby">
                        <div class="sectionTitle">
                            <h2><?php echo e($clientTitle->title); ?></h2>
                            <div class="titleBar left"></div>
                            <p>
                                <?php echo e($clientTitle->description); ?>

                            </p>
                        </div>
                        <div class="clientLogo">
                            <div class="row">
                                <?php $__currentLoopData = $clientBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($brand->status ==1): ?>
                                   <div class="col-sm-6 noPadding">
                                    <div class="singleClient">
                                        <a href="#">
                                            <img src="<?php echo e($brand->logo); ?>" alt>
                                        </a>
                                    </div>
                                </div>
                                   <?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="swipeboxx/js/jquery.swipebox.min.js"></script><?php /**PATH D:\WebLink\everfresh\resources\views/welcome.blade.php ENDPATH**/ ?>