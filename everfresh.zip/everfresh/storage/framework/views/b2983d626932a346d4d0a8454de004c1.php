

<section class="headerTop">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="headertopIn">
                    <div class="row">
                        <div class="col-lg-4 col-sm-3">
                            <div class="logo">
                                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('storage/'.$homeTop->logo)); ?>" alt></a>
                            </div>
                        </div>
                        <div class="col-lg-8 col-sm-9">
                            <div class="rightheadtop">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="topinfo boright">
                                            <i class="icon-Phone2"></i>
                                            <h5>get in touch</h5>
                                            <h6>+977 <?php echo e($homeTop->number); ?></h6>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="topinfo boright">
                                            <i class="icon-Pointer"></i>
                                            <h5>OUR OFFICE</h5>
                                            <h6><?php echo e($homeTop->location); ?></h6>
                                        </div>
                                    </div>
                                    <div class="col-sm-4 text-right topbtnpos">
                                        <a href="#" class="cleanBtn_style1">Get free Estimate <i
                                                class="fa fa-angle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<header class="header1">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-2 logoHidden">
                <div class="logohi">
                    <a href="<?php echo e(url('/')); ?>"><img src="images/LOGO1.png" alt></a>
                </div>
            </div>

            <div class="col-md-9 text-center">
                <nav class="mainNav">
                    <div class="mobileMenu hidden-lg hidden-md">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                        <li class="has-menu-items"><a href="<?php echo e(url('/')); ?>">home</a>
                            
                        </li>
                        <li class="has-menu-items"><a href="<?php echo e(route('everfresh.home.about')); ?>">About Us</a>
                            
                        </li>
                        <li class="has-menu-items"><a href="<?php echo e(route('everfresh.home.service')); ?>">services</a>
                            
                        </li>
                        <li class="has-menu-items"><a href="<?php echo e(route('everfresh.home.gallery')); ?>">Gallery</a>
                            
                        </li>
                        <li class="has-menu-items"><a href="<?php echo e(route('everfresh.home.blog')); ?>">Blog</a>
                            
                        </li>

                        <li><a href="<?php echo e(route('everfresh.home.contact')); ?>">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header><?php /**PATH D:\WebLink\everfresh\resources\views/template/navlink.blade.php ENDPATH**/ ?>