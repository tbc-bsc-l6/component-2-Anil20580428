

<?php $__env->startSection('content'); ?>
  


    <div class="d-flex justify-content-between align-items-center mb-3 mt-4">
      <!-- Left-aligned Heading -->
      <h3 class="mb-0">Slider Manage or Add/Delete/Update</h3>
      
      <!-- Right-aligned Button -->
      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#slider"><i class="bi bi-plus-square"></i>Add Slider</button>
  </div>
  
                <!--slider Modal -->
<div class="modal fade" id="slider" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('homepage.slider.add')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
              <label for="heading1" class="form-label">Heading One</label>
              <input name="heading1"  type="text" class="form-control" id="heading1" aria-describedby="heading1">
            </div>
          <div class="mb-3">
              <label for="heading2" class="form-label">location</label>
              <input name="heading2" type="text" class="form-control" id="heading2" aria-describedby="heading2">
            </div>
            <div class="mb-3">
              <label for="description" class="form-label">Slider Description</label>
              <input name="description" type="text" class="form-control" id="description" aria-describedby="description">
            </div>
            <div class="mb-3">
              <label for="sliderimage" class="form-label">Slider Image</label>
              <input name="sliderimage" type="file" class="form-control" id="sliderimage" aria-describedby="sliderimage">
            </div>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
        </form>
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="container">
    <div class="col-lg-12">
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <?php $__currentLoopData = $homeslider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php echo e($index); ?>" 
                        class="<?php echo e($index == 0 ? 'active' : ''); ?>" 
                        aria-current="<?php echo e($index == 0 ? 'true' : 'false'); ?>" 
                        aria-label="Slide <?php echo e($index + 1); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="carousel-inner">
          <?php $__currentLoopData = $homeslider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
              <img src="<?php echo e(asset($slider->sliderimage)); ?>" class="d-block w-100" alt="...">
              <div class="carousel-caption d-none d-md-block">
                  <h5 class="text-center"><?php echo e($slider->heading1); ?></h5>
                  <h4 class="text-center"><?php echo e($slider->heading2); ?></h4>
                  <p class="text-center"><?php echo e($slider->description); ?></p>
                  
                  <!-- Buttons on the same line -->
                  <div class="d-flex justify-content-center gap-2 mt-2">
                      <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#slideredit<?php echo e($slider->id); ?>">
                          <i class="bi bi-pencil-square"></i> Edit
                      </button>
                      <form action="<?php echo e(route('homepage.slider.delete', $slider->id)); ?>" method="POST" class="d-inline-block">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button type="submit" class="btn btn-danger">
                              <i class="bi bi-trash3"></i> Delete
                          </button>
                      </form>
                  </div>
              </div>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    
    <!-- Edit Slider Modal -->
    <?php $__currentLoopData = $homeslider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="slideredit<?php echo e($slider->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Slider</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('homepage.slider.edit', $slider->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="heading1" class="form-label">Heading One</label>
                                <input name="heading1" value="<?php echo e($slider->heading1); ?>" type="text" class="form-control" id="heading1">
                            </div>
                            <div class="mb-3">
                                <label for="heading2" class="form-label">Location</label>
                                <input name="heading2" value="<?php echo e($slider->heading2); ?>" type="text" class="form-control" id="heading2">
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Slider Description</label>
                                <input name="description" value="<?php echo e($slider->description); ?>" type="text" class="form-control" id="description">
                            </div>
                      
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </div>
</div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/homepage.blade.php ENDPATH**/ ?>