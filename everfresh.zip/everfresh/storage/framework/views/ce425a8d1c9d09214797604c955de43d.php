

<?php $__env->startSection('content'); ?>
    <div class="mt-4">

        <div class="container">
            <div class="row form-container">
                <div class="col-lg-12">
                   
                    <div class="form-card">
                        <h3 class="text-center">Contact Us</h3>
                        <form method="POST" action="<?php echo e(route('contact.info.edit')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
        
                            <div class="mb-2">
                                <textarea name="description" class="form-control" id="description" rows="3"><?php echo e($contactInfo->description); ?></textarea>
                            </div>
        
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-info">edit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


<!-- Table -->
<table class="table table-bordered border-dark">
    <thead class="bg-dark text-white text-center">
        <tr>
            <th scope="col">Sr No</th>
            <th scope="col">Full Name</th>
            <th scope="col">Email</th>
            <th scope="col">Comment</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $userContactInforamtion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userMessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row" class="text-center align-middle"><?php echo e($userMessage->id); ?></th>
            <td class="text-center align-middle">
                <?php echo e($userMessage->firstName); ?> <?php echo e($userMessage->lastName); ?>

            </td>
            <td class="align-middle"><?php echo e($userMessage->email); ?></td>
            <td class="align-middle"><?php echo e($userMessage->comment); ?></td>
            
            <td class="text-center align-middle">
                <div class="d-flex justify-content-center gap-2">
                    <!-- Active/Inactive Toggle -->
                    <form action="<?php echo e(route('user.status.toggle', $userMessage->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <button type="submit" class="btn btn-sm btn-<?php echo e($userMessage->status == 1 ? 'secondary' : 'success'); ?> d-flex align-items-center">
                            <i class="bi bi-<?php echo e($userMessage->status == 1 ? 'eye-slash' : 'eye'); ?> me-1"></i>
                            <?php echo e($userMessage->status == 1 ? 'Inactive' : 'Active'); ?>

                        </button>
                    </form>

                    <!-- Delete -->
                    <form action="<?php echo e(route('user.delete', $userMessage->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger d-flex align-items-center" onclick="return confirm('Are you sure you want to delete this item?')">
                            <i class="bi bi-trash me-1"></i> Delete
                        </button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/userContact.blade.php ENDPATH**/ ?>