

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h1 class="bg-primary-subtle text-center text-dark py-3 px-3">Call To Action </h1>

        <!-- Form to update banner -->
        <form method="POST" action="<?php echo e(route('our.banner.update')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    <div class="form-group">
    <label for="logo">Logo</label>
    <input type="file" class="form-control" id="logo" name="logo">
    <?php if($banner->logo): ?>
    <img src="<?php echo e(asset('storage/' . $banner->logo)); ?>" class="card-img-left" alt="Logo" style="width: 18rem;">

    <?php endif; ?>
    </div>
    <div class="form-group">
    <label for="heading">Heading</label>
    <input type="text" class="form-control" id="heading" name="heading" value="<?php echo e($banner->heading); ?>" required>
</div>
<div class="form-group">
    <label for="description">Description</label>
    <textarea class="form-control" id="description" name="description" rows="6" required><?php echo e($banner->description); ?></textarea>
</div>
<button type="submit" class="btn btn-sm btn-info mt-2 ml-3">Update Banner</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/callaction.blade.php ENDPATH**/ ?>