<?php echo $__env->make('template.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('template.navlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="breadcrumbSection">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="pageTitle">
                        <h2>Blog</h2>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="pageBreadcrumb">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                        <span>&nbsp; / &nbsp;</span>
                        <a href="#">Blog</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="commonSection">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-sm-7">
                    <div class="row">
                        <?php $__currentLoopData = $blogAdd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogadd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <div class="col-lg-6 wow fadeInUp" data-wow-duration="700ms" data-wow-delay="300ms">
                            <div class="singleBlog">
                                <div class="blogImg">
                                    <img alt src="<?php echo e(asset($blogadd->image)); ?>">
                                </div>
                                <div class="blogMeta">
                                    <div class="blAuthor">
                                        <a href="#"> <img alt
                                                src="<?php echo e(asset($blogadd->profile)); ?>"></a>
                                    </div>
                                    <a class="blmDate" href="#"><?php echo e($blogadd->date); ?></a>
                                </div>
                                <div class="blogcont">
                                    <h2><a href="<?php echo e(route('blog.details',$blogadd->id)); ?>"><?php echo e($blogadd->heading); ?></a></h2>
                                    <div class="blogDec">
                                        <p>
                                            <?php echo $blogadd->description1; ?> <a href="#">[...]</a>
                                        </p>
                                    </div>
                                    <div class="blogMetaBott">
                                        <a class="breadmore" href=" ">Read More<i
                                                class="fa fa-angle-double-right"></i></a>
                                        <a href="#"><i class="fa fa-heart-o"></i>12 Likes</a>
                                        <a href="#"><i class="fa fa-comments-o"></i>07 Comments</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="clearfix"></div>
                       
                    </div>
                </div>
                <div class="col-lg-4 col-sm-5 sidebars">
                    <aside class="widget wow fadeInUp" data-wow-duration="700ms" data-wow-delay="300ms">
                        <h3 class="widgetTitle">Search Product</h3>
                        <form action="#" class="woocommerce-product-search" method="get" role="search">
                            <input type="search" title="Enter Keyword" name="s" value placeholder="Enter Keyword">
                            <input type="submit" value="Search">
                        </form>
                    </aside>
                    <aside class="widget wow fadeInUp" data-wow-duration="700ms" data-wow-delay="350ms">
                        <h3 class="widgetTitle">Latest Post</h3>
                        <div class="latestPost">
                            <?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <div class="singlatPost">
                                <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt>
                                <h2 class="fmOpensans bloglatTitle">
                                    <a href="#"><?php echo e($post->description); ?></a>
                                </h2>
                                <p><a href="#"><?php echo e($post->date); ?></a></p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </aside>
                    <aside class="widget wow fadeInUp" data-wow-duration="700ms" data-wow-delay="400ms">
                        <div class="promos">
                            <img src="https://themewar.com/html/myclean/images/blog/promosion.jpg" alt />
                        </div>
                    </aside>
                    <aside class="widget wow fadeInUp" data-wow-duration="700ms" data-wow-delay="450ms">
                        <h3 class="widgetTitle">Categories</h3>
                        <ul class="product-categories">
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="#"><?php echo e($item->cname); ?></a><span class="count">(<?php echo e($item->total); ?>)</span></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </ul>
                    </aside>
                    <aside class="widget wow fadeInUp" data-wow-duration="700ms" data-wow-delay="500ms">
                        <h3 class="widgetTitle">Text Widget</h3>
                        <div class="textWidget">
                            <p>
                                Than he so join us here <a href="#">each week my friends</a> you
                                are sure to get a <span>smile from seven</span> stranded
                                castaways week my friends.
                            </p>
                        </div>
                    </aside>
                    <aside class="widget noMarginBottom wow fadeInUp" data-wow-duration="700ms" data-wow-delay="550ms">
                        <h3 class="widgetTitle">Tags</h3>
                        <div class="tagCloude">
                            <a href="#">Tips</a>
                            <a href="#">Tricks</a>
                            <a href="#">Cleaning</a>
                            <a href="#">Streaming</a>
                            <a href="#">Fresh air</a>
                            <a href="#">Healthy</a>
                            <a href="#">Offers</a>
                            <a href="#">Clean Surroundings</a>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/blog.blade.php ENDPATH**/ ?>