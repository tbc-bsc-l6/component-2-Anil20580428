

<?php $__env->startSection('content'); ?>
<div class="mb-3 mt-5">
    <a href="<?php echo e(route('add.blogs')); ?>" class="btn btn-primary">
        Add Blog
    </a>
</div>

<!-- Add Blog Modal -->
<div class="modal fade" id="addBlogModal" tabindex="-1" aria-labelledby="addBlogModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBlogModalLabel">Add New Blog</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
           
        </div>
    </div>
</div>

<!-- Table to Display Blogs -->
<table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th>#</th>
            <th>Image</th>
            <th>Date</th>
            <th>Heading</th>
            <th>Description</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><img src="<?php echo e(asset($blog->image)); ?>" alt="Image" width="100" height="60"></td>
            <td><?php echo e($blog->date); ?></td>
            <td><?php echo e($blog->heading); ?></td>
            <td><?php echo $blog->description1; ?></td>
            <td>
                <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#viewModal<?php echo e($blog->id); ?>">View</button>
                <a class="btn btn-secondary" href="<?php echo e(route('edit.blogs',$blog->id)); ?>">Edit</a>
                <form action="<?php echo e(route('blog.adds.delete', $blog->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this blog?')">Delete</button>
                </form>
            </td>
        </tr>

        <!-- View Blog Modal -->
<div class="modal fade" id="viewModal<?php echo e($blog->id); ?>" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewModalLabel">View Blog Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- Left Column: Image and Profile -->
                    <div class="col-4 text-center">
                        <img id="view-image" src="<?php echo e(asset($blog->image)); ?>" alt="Blog Image" class="img-fluid mb-3" style="max-height: 200px;">
                        <img id="view-profile" src="<?php echo e(asset($blog->profile)); ?>" alt="Profile Image" class="img-fluid" style="max-height: 100px;">
                    </div>
                    <!-- Right Column: Blog Details -->
                    <div class="col-8">
                        <p><strong>Date:</strong> <span id="view-date"><?php echo e($blog->date); ?></span></p>
                        <p><strong>Heading:</strong> <span id="view-heading"><?php echo e($blog->heading); ?></span></p>
                        <p><strong>Description 1:</strong> <span id="view-description1"><?php echo $blog->description1; ?></span></p>
                        <p><strong>Description 2:</strong> <span id="view-description2"><?php echo e($blog->description2); ?></span></p>
                        <p><strong>Description 3:</strong> <span id="view-description3"><?php echo e($blog->description3); ?></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/blogAdd.blade.php ENDPATH**/ ?>