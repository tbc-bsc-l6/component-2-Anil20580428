

<?php $__env->startSection('content'); ?>
<div class="mt-4">

    <!-- Table -->
    <h3 class="text-dark">Logo and Company Information</h3>
    <table class="table table-bordered border-dark">
        <thead class="bg-dark text-white">
            <tr>
                <th scope="col">Sr no</th>
                <th scope="col">Logo</th>
                <th scope="col">Number</th>
                <th scope="col">Location</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">1</th>
                <td>
                    <div class="card" style="width: 18rem;">
                        <img src="<?php echo e(asset('storage/' .$hometop->logo)); ?>" class="card-img-top w-100" alt="Logo">   
                    </div>
                </td>
                <td><?php echo e($hometop->number); ?></td>
                <td><?php echo e($hometop->location); ?></td>
                <td>
                    <button class="btn btn-sm btn-info"><i class="bi bi-eye"></i> Active</button>
                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="bi bi-pencil-square"></i> Edit</button>
                </td>
            </tr>
        </tbody>
    </table>

    <!-- Modal for editing logo and company information -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Company Information</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('homepage.top.update')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="number" class="form-label">Number</label>
                            <input name="number" value="<?php echo e($hometop->number); ?>" type="number" class="form-control" id="number" aria-describedby="number">
                        </div>
                        <div class="mb-3">
                            <label for="location" class="form-label">Location</label>
                            <input name="location" value="<?php echo e($hometop->location); ?>" type="text" class="form-control" id="location" aria-describedby="location">
                        </div>
                        <div class="mb-3">
                            <label for="logo" class="form-label">Logo</label>
                            <input name="logo" type="file" class="form-control" id="logo" aria-describedby="logo">
                        </div>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Slider Left and Right Information -->
    <h3 class="text-dark py-3 text-center">Date and Time</h3>

    <!-- Table displaying Slider Left and Right content -->
    <table class="table table-bordered border-dark">
        <thead class="bg-dark text-white">
            <tr>
                <th scope="col">SliderButton</th>
                <th scope="col">Heading</th>
                <th scope="col">Content</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Slider Left -->
            <tr>
                <th scope="row">Left</th>
                <td><?php echo e($sliderLeft->heading); ?></td>
                <td>
                    <p><strong>Day 1:</strong> <?php echo e($sliderLeft->day1); ?></p>
                    <p><strong>Day 2:</strong> <?php echo e($sliderLeft->day2); ?></p>
                    <h5><?php echo e($sliderLeft->title); ?></h5>
                    <p><?php echo e($sliderLeft->phone); ?></p>
                </td>
                <td>
                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#exampleModalLeft"><i class="bi bi-pencil-square"></i> Edit</button>
                </td>
            </tr>

            <!-- Slider Right -->
            <tr>
                <th scope="row">Right</th>
                <td><?php echo e($sliderRight->heading); ?></td>
                <td><?php echo e($sliderRight->description); ?></td>
                <td>
                    <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#exampleModalRight"><i class="bi bi-pencil-square"></i> Edit</button>
                </td>
            </tr>
        </tbody>
    </table>

    <!-- Modal for editing Slider Left -->
    <div class="modal fade" id="exampleModalLeft" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Slider Left</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('sliderLeft.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="heading" class="form-label">Heading</label>
                            <input type="text" class="form-control" id="heading" name="heading" value="<?php echo e($sliderLeft->heading); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="day1" class="form-label">Day 1</label>
                            <input type="text" class="form-control" id="day1" name="day1" value="<?php echo e($sliderLeft->day1); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="day2" class="form-label">Day 2</label>
                            <input type="text" class="form-control" id="day2" name="day2" value="<?php echo e($sliderLeft->day2); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo e($sliderLeft->title); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($sliderLeft->phone); ?>" required>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for editing Slider Right -->
    <div class="modal fade" id="exampleModalRight" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Slider Right</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('sliderRight.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="heading" class="form-label">Heading</label>
                            <input type="text" class="form-control" id="heading" name="heading" value="<?php echo e($sliderRight->heading); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <input type="text" class="form-control" id="description" name="description" value="<?php echo e($sliderRight->description); ?>" required>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/companyDesc.blade.php ENDPATH**/ ?>