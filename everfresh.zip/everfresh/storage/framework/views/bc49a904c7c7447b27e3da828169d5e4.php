

<?php $__env->startSection('content'); ?>
    <div class="mt-4">

        <form action="<?php echo e(route('footer.short.desc.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
              <label for="description" class="form-label">Description</label>
              <textarea type="text" name="description" class="form-control fs-4 fw-3" id="description" rows="4"><?php echo e($shortDesc->description); ?></textarea>
            </div>
           
            <button type="submit" class="btn btn-primary">update</button>
          </form>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/admin/footerShortDesc.blade.php ENDPATH**/ ?>