<?php echo $__env->make('template.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('template.navlink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('template.home_slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>








<section class="commonSection bggray noPaddingBottom welcomeSec">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="spSecTitle">
                    <h2>
                        Welcome to EVERFRESH <br>
                        we have over <span>15 Years </span> of Experience
                    </h2>
                    <div class="titleBar"></div>
                    <p>
                        The helpless the powerless in a world of criminals who
                        operate above the law texas tea here is the story of<br> a man
                        named Brady who was busy with three boys
                        they call him Flipper Flipper faster than lightning.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="welclean">
        <div class="welimg wow fadeInUp" data-wow-duration="700ms" data-wow-delay="300ms">
            <img src="https://themewar.com/html/myclean/images/home1/welcome.jpg" alt>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 iconbox1wrap">
                    <div class="row">
                        <div class="col-sm-6 text-right noPaddingRight wow fadeInUp" data-wow-duration="700ms"
                            data-wow-delay="300ms">
                            <div class="iconbox1">
                                <i class="fa-solid fa-fill-drip"></i>
                                <h2>Who Are We</h2>
                                <p>
                                    The walking on air they call him Flipper Flipper
                                    faster than lightning no one you see is smarter than he so join now.
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-6 text-right wow fadeInUp" data-wow-duration="700ms"
                            data-wow-delay="350ms">
                            <div class="iconbox1">
                                <i class="fa-regular fa-lightbulb"></i>
                                <h2>What We Do</h2>
                                <p>
                                    The walking on air they call him Flipper Flipper
                                    faster than lightning no one you see is smarter than he so join now.
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-6 text-right noPaddingRight wow fadeInUp" data-wow-duration="700ms"
                            data-wow-delay="400ms">
                            <div class="iconbox1">
                                <i class="fa-solid fa-gift"></i>
                                <h2>Our Mission</h2>
                                <p>
                                    The walking on air they call him Flipper Flipper
                                    faster than lightning no one you see is smarter than he so join now.
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-6 text-right wow fadeInUp" data-wow-duration="700ms"
                            data-wow-delay="450ms">
                            <div class="iconbox1">
                                <i class="fa-brands fa-react"></i>
                                <h2>Our Vision</h2>
                                <p>
                                    The walking on air they call him Flipper Flipper
                                    faster than lightning no one you see is smarter than he so join now.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="commonSection noPaddingBottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="sectionTitle text-center">
                    <h2> Our Projects</h2>
                    <div class="titleBar"></div>
                    <p>
                        The helpless the powerless in a world of criminals who operate above the law texas tea here
                        is the story
                        of<br> a man named Brady who was busy with three boys they call him Flipper Flipper faster
                        than lightning.
                    </p>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <div class="text-center">
                <div class="filterNav">
                    <ul class="nav nav-tabs filterNav" role="tablist">
                        <li role="presentation" class="active">
                            <a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">All Projects</a>
                        </li>
                        <li role="presentation">
                            <a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Flooring</a>
                        </li>
                        <li role="presentation">
                            <a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Commercial</a>
                        </li>
                        <li role="presentation">
                            <a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab">Exterior</a>
                        </li>
                        <li role="presentation">
                            <a href="#tab5" aria-controls="tab5" role="tab" data-toggle="tab">Streaming</a>
                        </li>
                        <li role="presentation">
                            <a href="#tab6" aria-controls="tab6" role="tab" data-toggle="tab">Others</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="tab1">
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/1.jpg"
                            class="img-responsive" alt="Portfolio Image 1">
                            
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/1.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/2.jpg"
                            class="img-responsive" alt="Portfolio Image 2">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/2.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/3.jpg"
                            class="img-responsive" alt="Portfolio Image 3">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/3.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/4.jpg"
                            class="img-responsive" alt="Portfolio Image 4">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/4.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg"
                            class="img-responsive" alt="Portfolio Image 4">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/6.jpg"
                            class="img-responsive" alt="Portfolio Image 4">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/6.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/7.jpg"
                            class="img-responsive" alt="Portfolio Image 4">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/7.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg"
                            class="img-responsive" alt="Portfolio Image 4">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div role="tabpanel" class="tab-pane" id="tab2">
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg"
                            class="img-responsive" alt="Portfolio Image 5">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/6.jpg"
                            class="img-responsive" alt="Portfolio Image 6">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/6.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/7.jpg"
                            class="img-responsive" alt="Portfolio Image 7">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/7.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>

                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg"
                            class="img-responsive" alt="Portfolio Image 7">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div role="tabpanel" class="tab-pane" id="tab3">
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/7.jpg"
                            class="img-responsive" alt="Portfolio Image 7">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/7.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg"
                            class="img-responsive" alt="Portfolio Image 8">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/9.jpg"
                            class="img-responsive" alt="Portfolio Image 9">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/9.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/10.jpg"
                            class="img-responsive" alt="Portfolio Image 10">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/10.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div role="tabpanel" class="tab-pane" id="tab4">
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/2.jpg"
                            class="img-responsive" alt="Portfolio Image 7">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/2.jpg"class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg"
                            class="img-responsive" alt="Portfolio Image 8">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/6.jpg"
                            class="img-responsive" alt="Portfolio Image 9">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/6.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/1.jpg"
                            class="img-responsive" alt="Portfolio Image 10">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/1.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div role="tabpanel" class="tab-pane" id="tab5">
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/3.jpg"
                            class="img-responsive" alt="Portfolio Image 7">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/3.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg"
                            class="img-responsive" alt="Portfolio Image 8">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg"
                            class="img-responsive" alt="Portfolio Image 9">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/5.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/4.jpg"
                            class="img-responsive" alt="Portfolio Image 10">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/4.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div role="tabpanel" class="tab-pane" id="tab6">
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/2.jpg"
                            class="img-responsive" alt="Portfolio Image 7">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/2.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg"
                            class="img-responsive" alt="Portfolio Image 8">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/8.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/7.jpg"
                            class="img-responsive" alt="Portfolio Image 9">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/7.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-item">
                        <img src="https://themewar.com/html/myclean/images/portfolio/4c/4.jpg"
                            class="img-responsive" alt="Portfolio Image 10">
                        <div class="custom-overlay">
                            <div class="overlay-content">
                                <a href="https://themewar.com/html/myclean/images/portfolio/4c/4.jpg" class="swipebox"><i
                                        class="icon-Search"></i></a>
                                <h3><a href="gallery_single.html">Sparkling Colin</a></h3>
                                <p>Flooring</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="calltoaction">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-12">
                <div class="logo2call">
                    <img src="images/LOGO2.png" alt>
                </div>
            </div>
            <div class="col-lg-6 col-sm-12 noPaddingLeft">
                <div class="calltoCont">
                    <h2>We are Honest & our work make you Satisified</h2>
                    <p>
                        The law texas tea here is the story of a man named
                        Brady who was busy <br> with three boys they call him Flipper
                    </p>
                </div>
            </div>
            <div class="col-lg-3 col-sm-12 text-right">
                <div class="calltobtn">
                    <a href="#" class="cleanBtn_style2">Get free Estimate <i class="fa fa-angle-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="commonSection servicessec">
    <div class="container-fluid">
        <div class="row servPadding">
            <div class="col-lg-7">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="sectionTitle awesomeSer">
                            <h2>
                                Our Awesome Services
                            </h2>
                            <div class="titleBar left"></div>
                            <p>
                                The helpless the powerless in a world of criminals who operate above the law
                                texastea here <br>is
                                the story of a man named Brady who was busy with three boys of his own believe
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 noPaddingRight wow fadeInUp" data-wow-duration="700ms"
                        data-wow-delay="300ms">
                        <div class="iconbox2">
                            <i class="fa-solid fa-broom"></i>
                            <h2>Carpet Cleaning</h2>
                            <p>
                                The law texas tea here is the story of a man named
                                Brady who was busy with three boys of his own believe.
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6 noPaddingLeft wow fadeInUp" data-wow-duration="700ms"
                        data-wow-delay="350ms">
                        <div class="iconbox2">
                            <i class="fa-solid fa-broom"></i>
                            <h2>Floor Cleaning</h2>
                            <p>
                                The law texas tea here is the story of a man named
                                Brady who was busy with three boys of his own believe.
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6 noPaddingRight wow fadeInUp" data-wow-duration="700ms"
                        data-wow-delay="400ms">
                        <div class="iconbox2">
                            <i class="fa-solid fa-broom"></i>
                            <h2>Commercial Cleaning</h2>
                            <p>
                                The law texas tea here is the story of a man named
                                Brady who was busy with three boys of his own believe.
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6 noPaddingLeft wow fadeInUp" data-wow-duration="700ms"
                        data-wow-delay="450ms">
                        <div class="iconbox2">
                            <i class="fa-solid fa-broom"></i>
                            <h2>Carpet Cleaning</h2>
                            <p>
                                The law texas tea here is the story of a man named
                                Brady who was busy with three boys of his own believe.
                            </p>
                        </div>
                    </div>
                      
                </div>
            </div>
            <div class="col-lg-5 col-sm-12 noPadding">
                <div class="servicesContact">
                    <form action="#" method="post" id="servicesForm">
                        <div class="row">
                            <div class="col-lg-12">
                                <h2 class="serconttitle">Service Booking</h2>
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Name *" id="ser_name" name="ser_name"
                                    class="required">
                            </div>
                            <div class="col-lg-6">
                                <input type="email" placeholder="Email *" id="ser_email" name="ser_email"
                                    class="required">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Phone Number *" id="ser_phone" name="ser_phone"
                                    class="required">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Zip / Postal Code *" id="ser_post" name="ser_post"
                                    class="required">
                            </div>
                            <div class="col-lg-12">
                                <input type="text" placeholder="Address *" id="ser_adds" name="ser_adds"
                                    class="required">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="City *" id="ser_city" name="ser_city"
                                    class="required">
                            </div>
                            <div class="col-lg-6">
                                <select id="ser_option" class="required" name="ser_option">
                                    <option selected value>choose a services</option>
                                    <option value="Clean">Clean</option>
                                    <option value="mercedes">Mercedes</option>
                                    <option value="audi">Audi</option>
                                </select>
                            </div>
                            <div class="col-lg-12">
                                <textarea placeholder="Comments" id="ser_comment" name="ser_comment"
                                    class="required"></textarea>
                            </div>
                            <div class="col-lg-12">
                                <button type="submit" id="ser_submit">submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="testmonuial overlay80">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center" id="testcarohome1">
                <div class="singleTest">
                    <div class="testimg">
                        <img src="https://themewar.com/html/myclean/images/author/test1.jpg" alt>
                    </div>
                    <div class="testCont">
                        <p>
                            “ The helpless the powerless in a world of criminals who operate above the law texas tea
                            here is the story of a man named Brady who was busy with three boysof his own believe
                            the powerless
                            in a world of <br> criminals who operate above the law texas tea here is the story of a
                            man.”
                        </p>
                    </div>
                    <div class="testdeg">
                        <h4>Jaimon james</h4>
                        <p>Founder,Glitz</p>
                    </div>
                </div>
                <div class="singleTest">
                    <div class="testimg">
                        <img src="https://themewar.com/html/myclean/images/author/test1.jpg" alt>
                    </div>
                    <div class="testCont">
                        <p>
                            “ The helpless the powerless in a world of criminals who operate above the law texas tea
                            here is the story of a man named Brady who was busy with three boysof his own believe
                            the powerless
                            in a world of <br> criminals who operate above the law texas tea here is the story of a
                            man.”
                        </p>
                    </div>
                    <div class="testdeg">
                        <h4>Jaimon james</h4>
                        <p>Founder,Glitz</p>
                    </div>
                </div>
                <div class="singleTest">
                    <div class="testimg">
                        <img src="https://themewar.com/html/myclean/images/author/test1.jpg" alt>
                    </div>
                    <div class="testCont">
                        <p>
                            “ The helpless the powerless in a world of criminals who operate above the law texas tea
                            here is the story of a man named Brady who was busy with three boysof his own believe
                            the powerless
                            in a world of <br> criminals who operate above the law texas tea here is the story of a
                            man.”
                        </p>
                    </div>
                    <div class="testdeg">
                        <h4>Jaimon james</h4>
                        <p>Founder,Glitz</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="commonSection noPaddingBottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="sectionTitle text-center">
                    <h2> Meet Our Team</h2>
                    <div class="titleBar"></div>
                    <p>
                        The helpless the powerless in a world of criminals who operate above the law texas tea here
                        is the story
                        of<br> a man named Brady who was busy with three boys they call him Flipper Flipper faster
                        than lightning.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 teamWrap">
                <div class="singleTeam">
                    <div class="singtemimg">
                        <img src="https://themewar.com/html/myclean/images/team/t3.jpg" alt>
                    </div>
                    <div class="sintemDec">
                        <h3>Mark Rowan</h3>
                        <h4>Founder</h4>
                    </div>
                </div>
                <div class="singleTeam">
                    <div class="singtemimg">
                        <img src="https://themewar.com/html/myclean/images/team/t2.jpg" alt>
                    </div>
                    <div class="sintemDec">
                        <h3>Mark Rowan</h3>
                        <h4>Founder</h4>
                    </div>
                </div>
                <div class="singleTeam">
                    <div class="singtemimg">
                        <img src="https://themewar.com/html/myclean/images/team/t1.jpg" alt>
                    </div>
                    <div class="sintemDec">
                        <h3>Mark Rowan</h3>
                        <h4>Founder</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="commonSection bggray plansec">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="sectionTitle text-center">
                    <h2> Our Best Plans</h2>
                    <div class="titleBar"></div>
                    <p>
                        The helpless the powerless in a world of criminals who operate above the law texas tea here
                        is the story
                        of<br> a man named Brady who was busy with three boys they call him Flipper Flipper faster
                        than lightning.
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-sm-6 text-center wow fadeInUp" data-wow-duration="700ms"
                data-wow-delay="300ms">
                <div class="singlePlan">
                    <div class="planHead">
                        <span class="dollcar">$</span>
                        <p class="price">20</p>
                        <span class="monthPlan">/ mon</span>
                    </div>
                    <div class="planTitle">
                        <p>basic plan</p>
                    </div>
                    <div class="planbody">
                        <ul>
                            <li>Basic Features</li>
                            <li>3 Cleanings</li>
                            <li>3 Movings</li>
                            <li>10 hours Calling</li>
                            <li>5 People at Work</li>
                            <li>Free Suggestions</li>
                            <li>Enhanced Security</li>
                        </ul>
                    </div>
                    <div class="planFoot">
                        <a href="#" class="cleanBtn_style2">Buy Now <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 text-center wow fadeInUp" data-wow-duration="700ms"
                data-wow-delay="350ms">
                <div class="singlePlan active">
                    <div class="planHead">
                        <span class="dollcar">$</span>
                        <p class="price">30</p>
                        <span class="monthPlan">/ mon</span>
                    </div>
                    <div class="planTitle">
                        <p>standard plan</p>
                    </div>
                    <div class="planbody">
                        <ul>
                            <li>Standard Features</li>
                            <li>5 Cleanings</li>
                            <li>5 Movings</li>
                            <li>15 hours Calling</li>
                            <li>10 People at Work</li>
                            <li>Free Suggestions</li>
                            <li>Enhanced Security</li>
                        </ul>
                    </div>
                    <div class="planFoot">
                        <a href="#" class="cleanBtn_style2">Buy Now <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 text-center wow fadeInUp" data-wow-duration="700ms"
                data-wow-delay="400ms">
                <div class="singlePlan">
                    <div class="planHead">
                        <span class="dollcar">$</span>
                        <p class="price">40</p>
                        <span class="monthPlan">/ mon</span>
                    </div>
                    <div class="planTitle">
                        <p>premium Plan</p>
                    </div>
                    <div class="planbody">
                        <ul>
                            <li>Premium Features</li>
                            <li>7 Cleanings</li>
                            <li>7 Movings</li>
                            <li>20 hours Calling</li>
                            <li>15 People at Work</li>
                            <li>Free Suggestions</li>
                            <li>Enhanced Security</li>
                        </ul>
                    </div>
                    <div class="planFoot">
                        <a href="#" class="cleanBtn_style2">Buy Now <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6 text-center wow fadeInUp" data-wow-duration="700ms"
                data-wow-delay="450ms">
                <div class="singlePlan">
                    <div class="planHead">
                        <span class="dollcar">$</span>
                        <p class="price">20</p>
                        <span class="monthPlan">/ mon</span>
                    </div>
                    <div class="planTitle">
                        <p>ultimate Plan</p>
                    </div>
                    <div class="planbody">
                        <ul>
                            <li>Ultimate Features</li>
                            <li>10 Cleanings</li>
                            <li>10 Movings</li>
                            <li>30 hours Calling</li>
                            <li>25 People at Work</li>
                            <li>Free Suggestions</li>
                            <li>Enhanced Security</li>
                        </ul>
                    </div>
                    <div class="planFoot">
                        <a href="#" class="cleanBtn_style2">Buy Now <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="videoSection overlay70v">
    <div id="videoWrap1">
        <video id="myVideo1" muted loop poster="images/welcome.jpg">
            <source src="https://themewar.com/html/myclean/video/video.mp4" type="video/mp4">
        </video>
    </div>
    <div class="vidContent">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Welcome to</h2>
                    <div class="playBtn">
                        <a href="javascript:void('0')" id="playVideos"></a>
                    </div>
                    <h3> EVERFRESH</h3>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="commonSection faqsec">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 noPaddingRight">
                <div class="paqwrap">
                    <div class="sectionTitle marginBbottom40">
                        <h2>FAQ</h2>
                        <div class="titleBar left"></div>
                        <p>
                            The helpless the powerless in a world of criminals who operate above <br>the law texas
                            tea here is the story of a man named Brady
                        </p>
                    </div>
                    <div class="faqaccordion">
                        <div class="panel-group" id="accordion">
                            <div class="panel">
                                <div class="panelHeading">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#faq1"
                                        class="panel-title">
                                        <i class="fa-solid fa-plus"></i>
                                        How do I know I can trust the people you send to my home?
                                    </a>
                                </div>
                                <div id="faq1" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>
                                            The law texas tea here is the story of a man named Brady who was busy
                                            with
                                            three boys they call him Flipper Flipper faster than lightning sometimes
                                            you want to go where everybody knows your name.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel">
                                <div class="panelHeading active">
                                    <a class="panel-title" data-toggle="collapse" data-parent="#accordion"
                                        href="#faq2">
                                        <i class="fa-solid fa-minus"></i>
                                        Will I need to pay any taxes if I hire a housekeeper?
                                    </a>
                                </div>
                                <div id="faq2" class="panel-collapse collapse in">
                                    <div class="panel-body">
                                        <p>
                                            The law texas tea here is the story of a man named Brady who was busy
                                            with
                                            three boys they call him Flipper Flipper faster than lightning sometimes
                                            you want to go where everybody knows your name.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel">
                                <div class="panelHeading">
                                    <a class="panel-title" data-toggle="collapse" data-parent="#accordion"
                                        href="#faq3">
                                        <i class="fa-solid fa-plus"></i>
                                        How often should I have my home cleaned?
                                    </a>
                                </div>
                                <div id="faq3" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>
                                            The law texas tea here is the story of a man named Brady who was busy
                                            with
                                            three boys they call him Flipper Flipper faster than lightning sometimes
                                            you want to go where everybody knows your name.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel">
                                <div class="panelHeading">
                                    <a class="panel-title" data-toggle="collapse" data-parent="#accordion"
                                        href="#faq4">
                                        <i class="fa-solid fa-plus"></i>
                                        Do I have to sign a contract?
                                    </a>
                                </div>
                                <div id="faq4" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>
                                            The law texas tea here is the story of a man named Brady who was busy
                                            with
                                            three boys they call him Flipper Flipper faster than lightning sometimes
                                            you want to go where everybody knows your name.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel lastpan">
                                <div class="panelHeading">
                                    <a class="panel-title" data-toggle="collapse" data-parent="#accordion"
                                        href="#faq5">
                                        <i class="rt-plus3"></i>
                                        Will I always have the same house cleaner?
                                    </a>
                                </div>
                                <div id="faq5" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <p>
                                            The law texas tea here is the story of a man named Brady who was busy
                                            with
                                            three boys they call him Flipper Flipper faster than lightning sometimes
                                            you want to go where everybody knows your name.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 noPaddingLeft">
                <div class="brustedby">
                    <div class="sectionTitle">
                        <h2>Trusted By</h2>
                        <div class="titleBar left"></div>
                        <p>
                            The helpless the powerless in a of crimals who operate above the law texas
                            tea here is the story of a man named Brady
                        </p>
                    </div>
                    <div class="clientLogo">
                        <div class="row">
                            <div class="col-sm-6 noPadding borderBottomD borderRightD">
                                <div class="singleClient">
                                    <a href="#">
                                        <img src="images/trust1.png" alt>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-6 noPadding borderBottomD">
                                <div class="singleClient">
                                    <a href="#">
                                        <img src="images/trust2.png" alt>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-6 noPadding borderRightD">
                                <div class="singleClient">
                                    <a href="#">
                                        <img src="images/trust3.png" alt>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-6 noPadding">
                                <div class="singleClient">
                                    <a href="#">
                                        <img src="images/trust5.png" alt>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLink\everfresh\resources\views/index.blade.php ENDPATH**/ ?>